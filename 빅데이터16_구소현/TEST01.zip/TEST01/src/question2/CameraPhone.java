package question2;

public class CameraPhone extends MobilePhone {

	public void picture(){ System.out.println("사진찍기"); }
	public void music(){ System.out.println("노래듣기"); }
}
