package question2;

public class SmartPhone extends CameraPhone {
	
	
	public void kakaoTalk(){ System.out.println("카톡보내기"); }
	public void wifi(){ System.out.println("무료 인터넷접속하기"); }
	
}
