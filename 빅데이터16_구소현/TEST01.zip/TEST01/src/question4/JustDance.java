package question4;

public class JustDance {

	public void startzel() {
		System.out.println("그래픽이 황홀한 zelda 시작!");
		
	}
	
	public void startdan() {
		System.out.println("신나는 댄스게임 시작!");
		
	}
	public void startMario() {
		System.out.println("귀여운 Mario 게임 시작!");
		
	}
	
}
