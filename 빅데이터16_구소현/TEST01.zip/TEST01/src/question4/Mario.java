package question4;

public class Mario extends JustDance {


	
	
}
