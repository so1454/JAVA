package question4;

public class Question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Zelda game1 = new Zelda ();
		Mario game2 = new Mario();
		JustDance game3 = new JustDance();
		
		
//		insert(game1);
//		insert(game2);
		insert(game3);
	}

	public static void insert(JustDance j)
	{
		game.start();
		
		
	}
	
	
	
	
}
