package question4;

public class Zelda extends JustDance {
	
	

		
	
	
}
