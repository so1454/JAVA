package question4;

public class game {

	public static void start() {
		// TODO Auto-generated method stub
		JustDance game3 = new JustDance();
		
		game3.startzel();
		game3.startMario();
		game3.startdan();
		
		
	}

}
